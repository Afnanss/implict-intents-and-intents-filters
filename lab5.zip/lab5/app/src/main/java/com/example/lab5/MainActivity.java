package com.example.lab5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void openWebSite(View v)
    {

    }

    public void sendSMS(View v)
    {

    }

    public void call(View v)
    {
        // HW
    }

    public void showContactList(View v)
    {

    }
}